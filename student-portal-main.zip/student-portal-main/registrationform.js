document.getElementById('loginpage').onclick = function() {
    window.location.href = 'index.html';
  };

  document.getElementById('admin').onclick = function() {
    window.location.href = 'adminpanal.html';
  };