document.getElementById('logOut').onclick = function() {
    window.location.href = '../index.html';
  };

  document.getElementById('home').onclick = function() {
    window.location.href = 'homepage.html';
  };

  document.getElementById('profile').onclick = function() {
    window.location.href = 'profile.html';
  };

  document.getElementById('changepass').onclick = function() {
    window.location.href = 'changepassword.html';
  };

  document.getElementById('class-routine').onclick = function() {
    window.location.href = 'classroutine.html';
  };
  